#!/bin/bash

kodi-send --action="Notification(GAMES,Launching RetroPie!,4000,/storage/.kodi/addons/script.retropie/logo.png)"

cd /storage/.kodi/addons/script.retropie/
mount /dev/mmcblk0p1 noobs
cp /storage/.kodi/addons/script.retropie/autoboot.txt /storage/.kodi/addons/script.retropie/noobs/autoboot.txt

sleep 2

cd /storage/.kodi/addons/script.retropie/
kodi-send --action="PlayMedia(/storage/.kodi/addons/script.retropie/launch.wav)"

sleep 1

reboot
