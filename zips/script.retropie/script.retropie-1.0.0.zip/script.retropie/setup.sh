#!/bin/bash

cd /storage/.kodi/addons/script.retropie/

chmod 777 *.sh

mount /dev/mmcblk0p5 5/
mount /dev/mmcblk0p6 6/
mount /dev/mmcblk0p7 7/
mount /dev/mmcblk0p8 8/
mount /dev/mmcblk0p9 9/
mount /dev/mmcblk0p10 10/
mount /dev/mmcblk0p11 11/
mount /dev/mmcblk0p12 12/
mount /dev/mmcblk0p13 13/


if [ -d /storage/.kodi/addons/script.retropie/5/home/pi/RetroPie/ ]
then
	./5.sh

elif [ -d /storage/.kodi/addons/script.retropie/6/home/pi/RetroPie/ ]
then
	./6.sh

elif [ -d /storage/.kodi/addons/script.retropie/7/home/pi/RetroPie/ ]
then
	./7.sh

elif [ -d /storage/.kodi/addons/script.retropie/8/home/pi/RetroPie/ ]
then
	./8.sh

elif [ -d /storage/.kodi/addons/script.retropie/9/home/pi/RetroPie/ ]
then
	./9.sh

elif [ -d /storage/.kodi/addons/script.retropie/10/home/pi/RetroPie/ ]
then
	./10.sh

elif [ -d /storage/.kodi/addons/script.retropie/11/home/pi/RetroPie/ ]
then
	./11.sh

elif [ -d /storage/.kodi/addons/script.retropie/12/home/pi/RetroPie/ ]
then
	./12.sh

elif [ -d /storage/.kodi/addons/script.retropie/13/home/pi/RetroPie/ ]
then
	./13.sh

else
echo "not found"


fi
