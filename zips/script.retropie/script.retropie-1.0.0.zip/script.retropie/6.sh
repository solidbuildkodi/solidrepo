#!/bin/bash

cd /storage/.kodi/addons/script.retropie/

./unmountall.sh

rm unmountall.sh

mv 6.txt autoboot.tx

rm *.txt

mv autoboot.tx autoboot.txt

rm addon.py

mv addon.p addon.py

./switch.sh
