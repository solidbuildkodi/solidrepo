#!/bin/bash

cd /storage/.kodi/addons/script.retropie/
umount 5
umount 6
umount 7
umount 8
umount 9
umount 10
umount 11
umount 12
umount 13

rm -r 5
rm -r 6
rm -r 7
rm -r 8
rm -r 9
rm -r 10
rm -r 11
rm -r 12
rm -r 13

rm 5.sh
rm 6.sh
rm 7.sh
rm 8.sh
rm 9.sh
rm 10.sh
rm 11.sh
rm 12.sh
rm 13.sh
