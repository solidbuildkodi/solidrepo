import os; os.chmod('/storage/.kodi/addons/script.retropie/setup.sh', 0777)

import subprocess

subprocess.call("/storage/.kodi/addons/script.retropie/setup.sh")
